import {INCREMENT,DECREMENT} from './action.js';
import {combineReducers} from 'redux';
var data;
export const  first=(state=0,action)=>{

switch(action.type){

	case "INCREMENT":	data=action.values +1;	console.log("Inside First Reducers");
		return Object.assign({},state,{
		newValue:data
		});
	case "DECREMENT":	data=action.values -1;	console.log("Inside First  decre Reducers");
		return Object.assign({},state,{
		newValue:data
		});
		default:
		return state;
}

}
