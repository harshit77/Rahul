import React from 'react';
import Header from './Header';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();
export default class App extends React.Component{
	constructor(props){
		super(props)
	}
	
	render(){
		return(
		<div>
		<MuiThemeProvider>
		<Header/>
		</MuiThemeProvider>
		</div>
		
		)
	}
	
}