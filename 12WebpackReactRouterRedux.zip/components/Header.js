import React from 'react';
import AppBar from 'material-ui/AppBar';
import IconMenu from 'material-ui/IconMenu';
import MapsPlace  from 'material-ui/svg-icons/maps/place';
import IconButton from 'material-ui/IconButton/IconButton';
import MenuItem from 'material-ui/MenuItem';
import NavigationMenu from 'material-ui/svg-icons/navigation/menu';


export default class Header extends React.Component
{
	constructor(props){
		super(props);
	
	}
	
	render(){
		return(
		<AppBar 
		title="Title" style={{position:"fixed"}}
		 iconElementLeft={<IconButton><NavigationMenu/></IconButton>}
         iconElementRight={ <IconMenu style={{position:"relative",right:10,top:0}} 
     iconButtonElement={<IconButton tooltip="Change Location" tooltipPosition="bottom-center" iconStyle={{fill:"#fff"}}><MapsPlace/></IconButton>} 
      anchorOrigin={{horizontal: 'right', vertical: 'top'}}
      targetOrigin={{horizontal: 'right', vertical: 'top'}}
    >
      <MenuItem primaryText="Lucknow" />
      <MenuItem primaryText="Agra" />
    </IconMenu>}

		 />
		)
		
	}
}